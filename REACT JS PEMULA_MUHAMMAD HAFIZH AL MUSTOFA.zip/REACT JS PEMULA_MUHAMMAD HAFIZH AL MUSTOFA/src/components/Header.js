const Header = () => {
    return (
        <div>
            <h2> Ini Adalah Components Header</h2>
        </div>
    )
}

export default Header