const Contact = () => {
    return (
        <div>
            <h2>This is Contact Page</h2>
        </div>
    )
}
 
export default Contact